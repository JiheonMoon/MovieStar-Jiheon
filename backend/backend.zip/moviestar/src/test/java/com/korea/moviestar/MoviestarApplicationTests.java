package com.korea.moviestar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviestarApplicationTests {

	@Test
	void contextLoads() {
	}

}
